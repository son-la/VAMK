seq = [25,39,52,68,20,89]
fil = lambda x : True if (x < 50) else False
print(list(filter(fil,seq)))


