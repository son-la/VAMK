import GUI

#Main function
#DB_functions.CreateDb() #If not exists

#my_db = DB_functions.DBConnection('product.db','product')

#my_db.insert('item1',3,145.1)
#my_db.insert('item2',2,15.1)
#my_db.insert('item3',3,142.1)
#my_db.insert('item4',5,145.1)

#print(my_db.select_all())
#print(my_db.search_name('item1'))
#print(my_db.search_amount(3))
#print(my_db.search_price(15.1))

s = GUI.GUI().Start()
