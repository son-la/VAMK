Run program by command:
	python3.4 main.py
