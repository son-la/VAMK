import GUI
import DB_functions

DB_functions.CreateDb()
s = GUI.GUI().Start()
